/*
** EPITECH PROJECT, 2020
** main.c
** File description:
** main
*/

#include <stdlib.h>
#include <stdio.h>
#include <limits.h>
#include "struct.h"

int main(int argc, char **argv)
{
    search_open();
    return(0);
}