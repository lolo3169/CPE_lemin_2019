/*
** EPITECH PROJECT, 2020
** main.c
** File description:
** main
*/

#include <stdlib.h>
#include <stdio.h>
#include <limits.h>
#include "struct.h"

int my_strlen(char *str)
{
    int i = 0;

    for (; str[i] != '\0'; i++);
    return (i + 1);
}

char *my_concat(char *str, char *copy, int nb_line)
{
    int i = 0;
    int j = 0;
    static int h = 0;
    for (; str[i] != '\0'; i++);
    if (h != 0) {
        str[i] = '\n';
        i++;
    }
    h++;
    for (; copy[j] != '\0'; j++, i++)
        str[i] = copy[j];
    str[i] = '\0';
    return (str);
}

char *my_realloc(char *str, char *copy, int nb_line)
{
    int i = my_strlen(str);
    int j = my_strlen(copy);
    int size = i + j;
    char *new_str = malloc(sizeof(char) * (size) + 1);

    new_str = my_concat(str, copy, nb_line);
    return (new_str);
}